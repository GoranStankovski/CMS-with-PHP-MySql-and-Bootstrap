<?php

class Config {
    
    const SMTP_HOST = 'smtp.mailtrap.io';
    
    const SMTP_PORT = 2525;
    
    const SMTP_USER = '87b81153daf1ca';
    
    const SMTP_PASSWORD = '1c4ec7327ce8c7';
    
    
}



?>