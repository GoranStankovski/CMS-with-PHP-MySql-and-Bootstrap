<?php

const _REGISTER = "Registrate";
const _USERNAME = "Nombrede usuario";
const _EMAIL = "Tu correo";
const _PASSWORD = "Tu clave";








?>