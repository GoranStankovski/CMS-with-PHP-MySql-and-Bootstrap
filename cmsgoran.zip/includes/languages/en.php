<?php

const _REGISTER = "Register";
const _USERNAME = "Enter Your username";
const _EMAIL = "Enter Your email";
const _PASSWORD = "Enter Your password";








?>