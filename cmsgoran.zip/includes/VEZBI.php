<?php

$name = 'KevinHart';
$city = 'Dubai';
$show = 'restricted';

$height = 5;
$age = 30;

$Assarray = array('name'=>$name,'city'=>'Dubai','$show'=>'restricted');

echo $Assarray['name'];






?>