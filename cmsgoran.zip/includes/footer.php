  <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Sagos 2019</p>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="/cmsgoran/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/cmsgoran/js/bootstrap.min.js"></script>

</body>

</html>
